package com.example.myschedule.ui.home;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.myschedule.R;
import com.example.myschedule.addkelas;
import com.example.myschedule.test;
import com.example.myschedule.ui.chat.ChatFragment;

public class HomeFragment extends Fragment {

    ImageView iv;
    ListView listView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home,container,false);

        iv = v.findViewById(R.id.add);
        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ts = getFragmentManager().beginTransaction();
                ts.replace(R.id.nav_host_fragment,new addkelas() );
                ts.commit();
            }
        });
        listView = (ListView)v.findViewById(R.id.lvhome);
        setupListView();

        return v;
    }

    public class SimpleAdapter extends BaseAdapter {

        public Context mContext;
        public LayoutInflater layoutInflater;
        public TextView title,semt,dosen;
        public String[] titleArray;
        public String[] semtArray;
        public String[] dosenArray;
        public ImageView imageView;


        public SimpleAdapter(Context context,String[] title, String[] semt, String[] dosen){
            mContext = context;
            titleArray = title;
            semtArray = semt;
            dosenArray = dosen;
            layoutInflater = LayoutInflater.from(context);

        }

        @Override
        public int getCount() {
            return titleArray.length;
        }

        @Override
        public Object getItem(int position) {
            return titleArray[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null){
                convertView = layoutInflater.inflate(R.layout.item_class,null);
            }

            title = (TextView)convertView.findViewById(R.id.mapel);
            semt = (TextView)convertView.findViewById(R.id.semester);
            dosen = (TextView)convertView.findViewById(R.id.namadosen);
            imageView = (ImageView) convertView.findViewById(R.id.fotodosen);

            title.setText(titleArray[position]);
            semt.setText(semtArray[position]);
            dosen.setText(dosenArray[position]);

            if (titleArray[position].equalsIgnoreCase("Pemrograman Mobile")){
                imageView.setImageResource(R.drawable.logo2);
            }else if(titleArray[position].equalsIgnoreCase("Pemrograman Web")){
                imageView.setImageResource(R.drawable.logo2);
            }else if(titleArray[position].equalsIgnoreCase("Basis Data")){
                imageView.setImageResource(R.drawable.logo2);
            }else if(titleArray[position].equalsIgnoreCase("Sistem Operasi")){
                imageView.setImageResource(R.drawable.logo2);
            }
            return convertView;
        }
    }

    public void setupListView(){
        String[] title = getResources().getStringArray(R.array.Mapel);
        String[] semt = getResources().getStringArray(R.array.Semt);
        String[] dosen = getResources().getStringArray(R.array.Dosen);

        SimpleAdapter simpleAdapter = new SimpleAdapter(getContext(),title,semt,dosen);
        listView.setAdapter(simpleAdapter);
    }
}
